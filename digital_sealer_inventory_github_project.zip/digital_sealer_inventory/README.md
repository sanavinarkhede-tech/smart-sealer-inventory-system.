# Digital Sealer Inventory Monitoring System

A modern Streamlit demo for an automotive Body Shop sealer storage area. Includes inventory management, simulated load-cell readings, low-stock alerts, transactions, shift-wise consumption reports, a digital storage view, and CSV/Excel exports.

> **SIMULATION MODE:** No physical load cell, PLC, gateway, sensor, or SAP connection is present. Demo data is held in Streamlit session state and is not a production database.

## Features
- Dashboard: total drums, physical inventory, full/partial/empty drums, consumption, stock cover, alerts, last update
- Add/edit/view/delete drum records, unique IDs, capacity, tare, gross weight, batch, SAP code, rack, received and expiry dates
- Simulated load-cell measurements, 1/5/10 kg and custom material issues, simulated full-drum receipt, reset demo data
- Transaction history with opening stock, receipts, issues, returns, adjustments and closing stock
- Separate physical inventory and SAP/book stock display
- Daily/shift consumption entry, formula calculation, kg per vehicle and trend chart
- Configurable drum threshold, minimum inventory, daily consumption, supplier lead time and safety stock
- Storage area cards with filters and drum details/history
- CSV exports and Excel workbook export

## Run locally
Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows
.venv\\Scripts\\activate
# macOS/Linux
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```
Open the local URL shown by Streamlit, usually `http://localhost:8501`.

## Push to GitHub
Create a repository such as `digital-sealer-inventory-monitor`. In this folder, run:

```bash
git init
git add app.py requirements.txt README.md .gitignore
git commit -m "Build digital sealer inventory monitoring demo"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/digital-sealer-inventory-monitor.git
git push -u origin main
```
Replace `YOUR-USERNAME` with your GitHub username. Or upload the four files through GitHub's web interface.

## Deploy to Streamlit Community Cloud
1. Sign in at https://share.streamlit.io/ using GitHub.
2. Choose **Create app**.
3. Select your repository, branch `main`, and main file path `app.py`.
4. Deploy; Streamlit installs packages from `requirements.txt`.

## Demo limitations and next steps
- Session data can reset when a session restarts or the app is redeployed. Download CSV/Excel snapshots to preserve demo records.
- No authentication, role-based access, persistent database, SAP integration, sensor integration or notification service is included.
- Today's consumption is based on production report rows dated today. A simulated weight change is logged as a transaction and is not automatically treated as production consumption.
- Book stock changes only when a user records a transaction and selects the option to apply it to demo book stock.
- Net sealer quantity is clamped to capacity: `max(0, min(capacity, gross weight - tare weight))`.
- Consumption formula: `Opening stock + Receipts - Closing stock - Returns`.
- Before production use, add authentication, audit trail, persistent storage, approved SAP integration, calibrated sensors/IoT gateway, notifications and plant cybersecurity review.
