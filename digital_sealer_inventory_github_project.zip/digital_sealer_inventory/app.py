import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import datetime, date, timedelta
import io

st.set_page_config(page_title="Digital Sealer Inventory", page_icon="🏭", layout="wide", initial_sidebar_state="expanded")
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap');
html,body,[class*="css"]{font-family:'DM Sans',sans-serif} .stApp{background:#f3f6fa}
[data-testid="stSidebar"]{background:#101d2c}[data-testid="stSidebar"] *{color:#e8eef6!important}
.hero{padding:25px 28px;border-radius:18px;background:linear-gradient(120deg,#10243a,#1b4660 65%,#167d87);color:white;margin-bottom:18px;box-shadow:0 8px 24px #10243a18}
.hero h1{font-family:'Space Grotesk',sans-serif;font-size:30px;line-height:1.15;margin:0 0 8px;color:white}.hero p{margin:0;color:#d6e5ef;font-size:14px}
.sim-pill{display:inline-block;background:#ffcf70;color:#352507;padding:5px 10px;border-radius:999px;font-size:11px;font-weight:800;letter-spacing:1px;margin-bottom:12px}
.metric-card{background:white;border:1px solid #e3eaf2;border-radius:15px;padding:17px 18px;min-height:112px;box-shadow:0 3px 12px #1a345008;margin-bottom:8px}
.metric-label{color:#718096;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.6px}.metric-value{color:#13283d;font-family:'Space Grotesk',sans-serif;font-size:27px;font-weight:700;margin-top:6px}.metric-note{color:#718096;font-size:12px;margin-top:4px}
.section-title{font-family:'Space Grotesk',sans-serif;font-size:20px;font-weight:700;color:#142b40;margin:10px 0 12px}.status{display:inline-block;padding:4px 9px;border-radius:999px;font-size:11px;font-weight:800}.normal{background:#d8f5e6;color:#147448}.low{background:#fff0cb;color:#8a5a00}.reorder{background:#ffe0dd;color:#a32920}.empty{background:#e7eaf0;color:#4b5563}
.stButton>button{border-radius:10px;font-weight:700}div[data-testid="stMetric"]{background:white;padding:14px 16px;border-radius:14px;border:1px solid #e3eaf2}
</style>""", unsafe_allow_html=True)

NOW = datetime.now()

def seed_drums():
    return pd.DataFrame([
      {"Drum ID":"SD-001","Sealer Name":"Body Seam Sealer","Sealer Type":"PVC","SAP Code":"MAT-450120","Lot/Batch":"LOT-26A01","Capacity (kg)":200.0,"Tare (kg)":18.0,"Gross Weight (kg)":218.0,"Location":"Rack A1","Date Received":date.today()-timedelta(days=8),"Expiry Date":date.today()+timedelta(days=172)},
      {"Drum ID":"SD-002","Sealer Name":"Body Seam Sealer","Sealer Type":"PVC","SAP Code":"MAT-450120","Lot/Batch":"LOT-26A02","Capacity (kg)":200.0,"Tare (kg)":18.0,"Gross Weight (kg)":168.0,"Location":"Rack A2","Date Received":date.today()-timedelta(days=6),"Expiry Date":date.today()+timedelta(days=174)},
      {"Drum ID":"SD-003","Sealer Name":"Hem Flange Sealer","Sealer Type":"PU","SAP Code":"MAT-450245","Lot/Batch":"LOT-26B11","Capacity (kg)":200.0,"Tare (kg)":19.0,"Gross Weight (kg)":91.0,"Location":"Rack B1","Date Received":date.today()-timedelta(days=12),"Expiry Date":date.today()+timedelta(days=168)},
      {"Drum ID":"SD-004","Sealer Name":"Underbody Sealer","Sealer Type":"PVC","SAP Code":"MAT-450311","Lot/Batch":"LOT-26C07","Capacity (kg)":200.0,"Tare (kg)":18.0,"Gross Weight (kg)":42.0,"Location":"Rack B2","Date Received":date.today()-timedelta(days=19),"Expiry Date":date.today()+timedelta(days=161)},
      {"Drum ID":"SD-005","Sealer Name":"Cavity Wax","Sealer Type":"Wax","SAP Code":"MAT-450402","Lot/Batch":"LOT-26D03","Capacity (kg)":200.0,"Tare (kg)":17.0,"Gross Weight (kg)":17.0,"Location":"Rack C1","Date Received":date.today()-timedelta(days=28),"Expiry Date":date.today()+timedelta(days=152)},
    ])

def initialize():
    if "drums" not in st.session_state: st.session_state.drums = seed_drums()
    if "transactions" not in st.session_state:
        st.session_state.transactions = pd.DataFrame([
          {"Date/Time":NOW-timedelta(hours=6),"Drum ID":"SD-001","Type":"Opening Stock","Quantity (kg)":182.0,"Operator":"Demo Operator","Remarks":"Demo opening balance"},
          {"Date/Time":NOW-timedelta(hours=3),"Drum ID":"SD-002","Type":"Material Received","Quantity (kg)":200.0,"Operator":"Store Team","Remarks":"Sample receipt"},
          {"Date/Time":NOW-timedelta(hours=2),"Drum ID":"SD-003","Type":"Material Issued","Quantity (kg)":5.0,"Operator":"Production","Remarks":"Sample production issue"},
        ])
    if "consumption" not in st.session_state:
        st.session_state.consumption = pd.DataFrame([
          {"Production Date":date.today()-timedelta(days=6),"Shift":"A","Vehicles Produced":115,"Opening Stock":970.0,"Receipts":200.0,"Closing Stock":1080.0,"Returns":5.0,"Actual Consumption (kg)":85.0},
          {"Production Date":date.today()-timedelta(days=5),"Shift":"B","Vehicles Produced":121,"Opening Stock":1080.0,"Receipts":0.0,"Closing Stock":984.0,"Returns":4.0,"Actual Consumption (kg)":92.0},
          {"Production Date":date.today()-timedelta(days=4),"Shift":"A","Vehicles Produced":118,"Opening Stock":984.0,"Receipts":200.0,"Closing Stock":1088.0,"Returns":6.0,"Actual Consumption (kg)":90.0},
          {"Production Date":date.today()-timedelta(days=3),"Shift":"B","Vehicles Produced":123,"Opening Stock":1088.0,"Receipts":0.0,"Closing Stock":995.0,"Returns":3.0,"Actual Consumption (kg)":90.0},
          {"Production Date":date.today()-timedelta(days=2),"Shift":"A","Vehicles Produced":119,"Opening Stock":995.0,"Receipts":200.0,"Closing Stock":1098.0,"Returns":4.0,"Actual Consumption (kg)":93.0},
          {"Production Date":date.today()-timedelta(days=1),"Shift":"B","Vehicles Produced":124,"Opening Stock":1098.0,"Receipts":0.0,"Closing Stock":1002.0,"Returns":3.0,"Actual Consumption (kg)":93.0},
        ])
    if "book_stock" not in st.session_state: st.session_state.book_stock = 1002.0
    if "last_update" not in st.session_state: st.session_state.last_update = NOW

def inventory(df=None):
    d=(df if df is not None else st.session_state.drums).copy()
    if d.empty:
        for col in ["Net (kg)","Remaining (%)","Status"]: d[col]=[]
        return d
    d["Net (kg)"]=(d["Gross Weight (kg)"]-d["Tare (kg)"]).clip(lower=0)
    d["Net (kg)"]=d[["Net (kg)","Capacity (kg)"]].min(axis=1)
    d["Remaining (%)"]=(d["Net (kg)"]/d["Capacity (kg)"].replace(0,1)*100).clip(0,100).round(1)
    threshold=st.session_state.get("drum_min_pct",20)
    def status(r):
        if r["Net (kg)"]<=0.01: return "Empty"
        if r["Remaining (%)"]<=threshold: return "Low Level"
        if r["Remaining (%)"]>=99.5: return "Full"
        return "In Use"
    d["Status"]=d.apply(status,axis=1)
    return d

def log_transaction(drum_id, typ, qty, operator, remarks):
    row=pd.DataFrame([{"Date/Time":datetime.now(),"Drum ID":drum_id,"Type":typ,"Quantity (kg)":float(qty),"Operator":operator,"Remarks":remarks}])
    st.session_state.transactions=pd.concat([row,st.session_state.transactions],ignore_index=True)
    st.session_state.last_update=datetime.now()

def metric(label,value,note=""):
    st.markdown(f'<div class="metric-card"><div class="metric-label">{label}</div><div class="metric-value">{value}</div><div class="metric-note">{note}</div></div>',unsafe_allow_html=True)

def set_net_qty(idx,qty):
    r=st.session_state.drums.loc[idx]
    qty=max(0.0,min(float(r["Capacity (kg)"]),float(qty)))
    st.session_state.drums.loc[idx,"Gross Weight (kg)"]=qty+float(r["Tare (kg)"])
    st.session_state.last_update=datetime.now()

initialize()
with st.sidebar:
    st.markdown("## 🏭 SEALER OPS")
    st.caption("BODY SHOP / MATERIAL CONTROL")
    st.markdown("---")
    page=st.radio("NAVIGATION",["Overview Dashboard","Drum Inventory","Sensor Simulation","Transactions","Consumption Reports","Storage Area View","Reports & Export"])
    st.markdown("---")
    st.markdown("### ⚙️ Alert settings")
    st.session_state.drum_min_pct=st.slider("Drum low-level threshold (%)",5,50,int(st.session_state.get("drum_min_pct",20)),5)
    st.session_state.avg_daily=st.number_input("Average daily consumption (kg)",min_value=1.0,max_value=5000.0,value=float(st.session_state.get("avg_daily",90.0)),step=5.0)
    st.session_state.lead_time=st.number_input("Supplier lead time (days)",min_value=0,max_value=60,value=int(st.session_state.get("lead_time",3)))
    st.session_state.safety_stock=st.number_input("Safety stock (kg)",min_value=0.0,max_value=5000.0,value=float(st.session_state.get("safety_stock",150.0)),step=25.0)
    st.session_state.min_total=st.number_input("Minimum total inventory (kg)",min_value=0.0,max_value=10000.0,value=float(st.session_state.get("min_total",450.0)),step=25.0)
    st.caption("DEMO DATA · Session memory only")

d=inventory(); total=float(d["Net (kg)"].sum()) if not d.empty else 0.0
full_count=int((d["Status"]=="Full").sum()) if not d.empty else 0
partial_count=int(d["Status"].isin(["In Use","Low Level"]).sum()) if not d.empty else 0
empty_count=int((d["Status"]=="Empty").sum()) if not d.empty else 0
cons=st.session_state.consumption.copy(); today_cons=float(cons.loc[cons["Production Date"]==date.today(),"Actual Consumption (kg)"].sum()) if not cons.empty else 0.0
avg=float(st.session_state.avg_daily); reorder_point=avg*float(st.session_state.lead_time)+float(st.session_state.safety_stock); days_left=total/avg if avg else 0
overall_alert="REORDER REQUIRED" if total<=reorder_point else ("LOW STOCK" if total<=float(st.session_state.min_total) else "NORMAL")
st.markdown(f'<div class="hero"><div class="sim-pill">● SIMULATION MODE — NO HARDWARE CONNECTED</div><h1>DIGITAL SEALER INVENTORY<br>MONITORING SYSTEM</h1><p>Automotive Manufacturing · Body Shop · Sealer Storage Area &nbsp; | &nbsp; Demo inventory, simulated load-cell readings and material traceability</p></div>',unsafe_allow_html=True)

if page=="Overview Dashboard":
    st.markdown('<div class="section-title">Operations overview</div>',unsafe_allow_html=True)
    cols=st.columns(4)
    for col,args in zip(cols,[("Total drums",f"{len(d)}","Registered drum records"),("Physical inventory",f"{total:,.1f} kg","Calculated from simulated net weight"),("Today's consumption",f"{today_cons:,.1f} kg","Report entries dated today"),("Stock cover",f"{days_left:.1f} days",f"At {avg:.0f} kg/day average")]):
        with col: metric(*args)
    cols=st.columns(4)
    for col,args in zip(cols,[("Full drums",str(full_count),"Ready for use"),("Partially used",str(partial_count),"In use or low level"),("Empty drums",str(empty_count),"Replacement required"),("Last update",st.session_state.last_update.strftime("%H:%M:%S"),st.session_state.last_update.strftime("%d %b %Y"))]):
        with col: metric(*args)
    left,right=st.columns([1.4,1])
    with left:
        st.markdown('<div class="section-title">Inventory by drum</div>',unsafe_allow_html=True)
        if not d.empty:
            fig=px.bar(d,x="Drum ID",y="Net (kg)",color="Status",text="Net (kg)",hover_data=["Sealer Type","Location","Remaining (%)"],color_discrete_map={"Full":"#15966b","In Use":"#2374ab","Low Level":"#e7a126","Empty":"#9aa6b2"})
            fig.update_layout(height=330,margin=dict(l=8,r=8,t=10,b=10),paper_bgcolor="white",plot_bgcolor="white",legend_title_text="")
            st.plotly_chart(fig,use_container_width=True)
    with right:
        st.markdown('<div class="section-title">Inventory health</div>',unsafe_allow_html=True)
        cls="normal" if overall_alert=="NORMAL" else "low" if overall_alert=="LOW STOCK" else "reorder"
        st.markdown(f'**Overall stock status:** <span class="status {cls}">{overall_alert}</span>',unsafe_allow_html=True)
        st.write(f"Reorder point: **{reorder_point:,.1f} kg**")
        st.progress(min(1.0,total/max(reorder_point,1.0)),text=f"{total:,.1f} kg physical stock / {reorder_point:,.1f} kg reorder point")
        if total<=reorder_point: st.error("Total inventory is at or below reorder point. Plan replenishment.")
        elif total<=float(st.session_state.min_total): st.warning("Inventory has reached minimum total inventory threshold.")
        else: st.success("Total inventory is above the configured reorder point.")
        lows=d[d["Status"].isin(["Low Level","Empty"])]
        if not lows.empty:
            st.markdown("**Drum-level alerts**")
            for _,r in lows.iterrows(): st.warning(f"{r['Drum ID']} · {r['Net (kg)']:.1f} kg · {r['Status']} · {r['Location']}")
        else: st.info("No drum-level low-stock alerts.")
    st.markdown('<div class="section-title">Recent activity</div>',unsafe_allow_html=True)
    st.dataframe(st.session_state.transactions.head(6),use_container_width=True,hide_index=True)

elif page=="Drum Inventory":
    st.markdown('<div class="section-title">Drum inventory management</div>',unsafe_allow_html=True)
    st.caption("Physical quantity is calculated from gross weight minus tare weight.")
    with st.expander("＋ Add a new drum"):
        with st.form("add_drum",clear_on_submit=True):
            c=st.columns(3); drum_id=c[0].text_input("Drum ID *",placeholder="SD-006"); name=c[1].text_input("Sealer name *",value="Body Seam Sealer"); typ=c[2].selectbox("Sealer type",["PVC","PU","Wax","Silicone","Other"])
            c=st.columns(3); sap=c[0].text_input("Material / SAP code",value="MAT-450120"); lot=c[1].text_input("Lot / batch number"); loc=c[2].text_input("Storage location",value="Rack D1")
            c=st.columns(3); capacity=c[0].number_input("Capacity (kg)",min_value=1.0,value=200.0,step=10.0); tare=c[1].number_input("Tare (kg)",min_value=0.0,value=18.0,step=.5); net=c[2].number_input("Remaining sealer (kg)",min_value=0.0,value=200.0,step=5.0)
            c=st.columns(2); received=c[0].date_input("Date received",value=date.today()); expiry=c[1].date_input("Expiry date",value=date.today()+timedelta(days=180))
            if st.form_submit_button("Add drum",type="primary",use_container_width=True):
                if not drum_id.strip() or not name.strip(): st.error("Drum ID and sealer name are required.")
                elif drum_id in st.session_state.drums["Drum ID"].values: st.error("Drum ID must be unique.")
                else:
                    new={"Drum ID":drum_id.strip(),"Sealer Name":name.strip(),"Sealer Type":typ,"SAP Code":sap,"Lot/Batch":lot,"Capacity (kg)":capacity,"Tare (kg)":tare,"Gross Weight (kg)":tare+min(net,capacity),"Location":loc,"Date Received":received,"Expiry Date":expiry}
                    st.session_state.drums=pd.concat([st.session_state.drums,pd.DataFrame([new])],ignore_index=True); log_transaction(drum_id,"Opening Stock",min(net,capacity),"Store Team","Drum record created"); st.success("Drum added."); st.rerun()
    d=inventory(); cols=["Drum ID","Sealer Name","Sealer Type","SAP Code","Lot/Batch","Capacity (kg)","Tare (kg)","Gross Weight (kg)","Net (kg)","Remaining (%)","Status","Location","Date Received","Expiry Date"]
    st.dataframe(d[cols],use_container_width=True,hide_index=True)
    st.markdown("#### Edit or remove a drum")
    if not d.empty:
        selected=st.selectbox("Select drum",d["Drum ID"].tolist(),key="edit_select"); idx=st.session_state.drums.index[st.session_state.drums["Drum ID"]==selected][0]; row=st.session_state.drums.loc[idx]
        with st.form("edit_drum"):
            c=st.columns(3); ename=c[0].text_input("Sealer name",value=str(row["Sealer Name"])); choices=["PVC","PU","Wax","Silicone","Other"]; etype=c[1].selectbox("Sealer type",choices,index=choices.index(row["Sealer Type"]) if row["Sealer Type"] in choices else 0); eloc=c[2].text_input("Location",value=str(row["Location"]))
            c=st.columns(3); esap=c[0].text_input("SAP code",value=str(row["SAP Code"])); elot=c[1].text_input("Lot / batch",value=str(row["Lot/Batch"])); ecap=c[2].number_input("Capacity (kg)",min_value=1.0,value=float(row["Capacity (kg)"]),step=10.0)
            c=st.columns(2); etare=c[0].number_input("Tare (kg)",min_value=0.0,value=float(row["Tare (kg)"]),step=.5); enet=c[1].number_input("Remaining sealer (kg)",min_value=0.0,max_value=float(ecap),value=min(float(row["Gross Weight (kg)"]-row["Tare (kg)"]),float(ecap)),step=1.0)
            if st.form_submit_button("Save changes",type="primary"):
                st.session_state.drums.loc[idx,["Sealer Name","Sealer Type","Location","SAP Code","Lot/Batch","Capacity (kg)","Tare (kg)","Gross Weight (kg)"]]=[ename,etype,eloc,esap,elot,ecap,etare,etare+min(enet,ecap)]; st.session_state.last_update=datetime.now(); st.success("Drum updated."); st.rerun()
        with st.expander("⚠️ Remove selected drum"):
            st.warning(f"Confirm removal of {selected}. This cannot be undone in this demo session.")
            confirm=st.checkbox(f"I confirm that {selected} should be deleted",key="confirm_delete")
            if st.button("Delete drum record",disabled=not confirm):
                st.session_state.drums=st.session_state.drums[st.session_state.drums["Drum ID"]!=selected].reset_index(drop=True); log_transaction(selected,"Adjustment",0,"Admin","Drum record deleted"); st.rerun()

elif page=="Sensor Simulation":
    st.markdown('<div class="section-title">Simulated sensor monitoring</div>',unsafe_allow_html=True)
    st.info("SIMULATION MODE: readings are generated from demo values. No physical load cell, PLC, gateway or sensor is connected.")
    d=inventory()
    if d.empty: st.warning("Add a drum in Drum Inventory first.")
    else:
        selected=st.selectbox("Select drum",d["Drum ID"].tolist()); idx=st.session_state.drums.index[st.session_state.drums["Drum ID"]==selected][0]; row=inventory().loc[lambda x:x["Drum ID"]==selected].iloc[0]
        c=st.columns(3)
        with c[0]: metric("Simulated gross weight",f"{row['Gross Weight (kg)']:.1f} kg","Demo load-cell reading")
        with c[1]: metric("Empty drum tare",f"{row['Tare (kg)']:.1f} kg","Configured drum tare")
        with c[2]: metric("Net sealer quantity",f"{row['Net (kg)']:.1f} kg",f"{row['Remaining (%)']:.1f}% remaining")
        st.progress(float(row["Remaining (%)"])/100,text=f"Remaining capacity · {row['Remaining (%)']:.1f}%")
        st.markdown("#### Simulate material issue")
        c=st.columns(4)
        for col,amount in zip(c[:3],[1,5,10]):
            with col:
                if st.button(f"− {amount} kg",use_container_width=True,key=f"issue_{amount}"):
                    used=min(amount,float(row["Net (kg)"])); set_net_qty(idx,float(row["Net (kg)"])-used); log_transaction(selected,"Material Issued",used,"Demo Operator",f"Simulated issue {used:.1f} kg"); st.rerun()
        with c[3]:
            with st.popover("Custom issue"):
                custom=st.number_input("Quantity (kg)",min_value=.1,max_value=1000.0,value=2.0,step=.5,key="custom_issue")
                if st.button("Apply custom issue"):
                    used=min(float(custom),float(row["Net (kg)"])); set_net_qty(idx,float(row["Net (kg)"])-used); log_transaction(selected,"Material Issued",used,"Demo Operator","Custom simulated issue"); st.rerun()
        left,right=st.columns(2)
        with left:
            with st.form("receipt_form"):
                st.markdown("#### Simulate receipt of a full drum"); rid=st.text_input("New Drum ID",value=f"SD-{len(st.session_state.drums)+1:03d}"); rloc=st.text_input("Storage location",value="Rack D1"); rtype=st.selectbox("Sealer type",["PVC","PU","Wax","Silicone","Other"])
                if st.form_submit_button("＋ Receive new 200 kg drum",type="primary",use_container_width=True):
                    if rid in st.session_state.drums["Drum ID"].values: st.error("Drum ID already exists.")
                    else:
                        new={"Drum ID":rid,"Sealer Name":"Body Seam Sealer","Sealer Type":rtype,"SAP Code":"MAT-DEMO","Lot/Batch":f"DEMO-{datetime.now():%H%M%S}","Capacity (kg)":200.0,"Tare (kg)":18.0,"Gross Weight (kg)":218.0,"Location":rloc,"Date Received":date.today(),"Expiry Date":date.today()+timedelta(days=180)}
                        st.session_state.drums=pd.concat([st.session_state.drums,pd.DataFrame([new])],ignore_index=True); log_transaction(rid,"Material Received",200,"Store Team","Simulated full drum receipt"); st.rerun()
        with right:
            st.markdown("#### Reset demo data"); st.write("Restore five sample drums and clear activity to the initial demo state.")
            if st.button("↻ Reset all demo data",use_container_width=True):
                for key in ["drums","transactions","consumption","book_stock","last_update"]: st.session_state.pop(key,None)
                initialize(); st.rerun()
        st.caption("Net sealer weight = gross measured weight − tare weight. Quantity is clamped between 0 kg and capacity.")

elif page=="Transactions":
    st.markdown('<div class="section-title">Inventory transactions</div>',unsafe_allow_html=True)
    st.caption("Physical inventory and SAP/book stock are separate. The demo book-stock value is not automatically reconciled to simulated sensor values.")
    c=st.columns(2)
    with c[0]: metric("Physical inventory",f"{total:,.1f} kg","Derived from drum readings")
    with c[1]: metric("SAP / book stock",f"{st.session_state.book_stock:,.1f} kg","Demo ledger value")
    with st.expander("＋ Record a transaction",expanded=True):
        with st.form("transaction_form"):
            c=st.columns(3); td=c[0].selectbox("Drum ID",["STORE / GENERAL"]+st.session_state.drums["Drum ID"].tolist()); tt=c[1].selectbox("Transaction type",["Opening Stock","Material Received","Material Issued","Material Returned","Adjustment","Closing Stock"]); tq=c[2].number_input("Quantity (kg)",min_value=0.0,value=0.0,step=1.0)
            c=st.columns(2); operator=c[0].text_input("User / operator",value="Store Team"); remarks=c[1].text_input("Remarks"); update_book=st.checkbox("Apply transaction to demo SAP/book stock",value=False)
            if st.form_submit_button("Record transaction",type="primary"):
                log_transaction(td,tt,tq,operator,remarks)
                if update_book:
                    if tt in ["Material Received","Material Returned","Opening Stock"]: st.session_state.book_stock+=tq
                    elif tt=="Material Issued": st.session_state.book_stock=max(0,st.session_state.book_stock-tq)
                    elif tt=="Adjustment": st.session_state.book_stock+=tq
                    elif tt=="Closing Stock": st.session_state.book_stock=tq
                st.success("Transaction recorded."); st.rerun()
    tx=st.session_state.transactions.copy()
    if not tx.empty:
        types=st.multiselect("Filter transaction type",sorted(tx["Type"].dropna().unique()),default=sorted(tx["Type"].dropna().unique())); tx=tx[tx["Type"].isin(types)]
        st.dataframe(tx,use_container_width=True,hide_index=True); st.download_button("⬇ Download transaction history CSV",tx.to_csv(index=False).encode("utf-8"),"sealer_transactions.csv","text/csv")

elif page=="Consumption Reports":
    st.markdown('<div class="section-title">Consumption monitoring</div>',unsafe_allow_html=True)
    st.caption("Actual consumption = Opening stock + Receipts − Closing stock − Returns. Classify losses and adjustments separately; do not assume every weight reduction is production consumption.")
    with st.form("consumption_form"):
        c=st.columns(3); pdte=c[0].date_input("Production date",value=date.today()); shift=c[1].selectbox("Shift",["A","B","C","General"]); vehicles=c[2].number_input("Vehicles produced",min_value=0,value=120,step=1)
        c=st.columns(4); opening=c[0].number_input("Opening stock (kg)",min_value=0.0,value=float(total),step=5.0); receipts=c[1].number_input("Receipts (kg)",min_value=0.0,value=0.0,step=5.0); closing=c[2].number_input("Closing stock (kg)",min_value=0.0,value=max(0.0,float(total)-90),step=5.0); returns=c[3].number_input("Returns (kg)",min_value=0.0,value=0.0,step=1.0)
        if st.form_submit_button("Calculate & save report",type="primary"):
            actual=float(opening)+float(receipts)-float(closing)-float(returns)
            if actual<0: st.error("Calculated consumption is negative. Check stock figures and returns.")
            else:
                per=actual/vehicles if vehicles else 0.0; new={"Production Date":pdte,"Shift":shift,"Vehicles Produced":int(vehicles),"Opening Stock":float(opening),"Receipts":float(receipts),"Closing Stock":float(closing),"Returns":float(returns),"Actual Consumption (kg)":actual,"Consumption / Vehicle (kg)":per}
                st.session_state.consumption=pd.concat([st.session_state.consumption,pd.DataFrame([new])],ignore_index=True); st.success(f"Saved: {actual:.1f} kg consumption; {per:.3f} kg/vehicle."); st.rerun()
    con=st.session_state.consumption.copy()
    if not con.empty:
        con["Consumption / Vehicle (kg)"]=con["Actual Consumption (kg)"]/con["Vehicles Produced"].replace(0,1)
        c=st.columns(3)
        with c[0]: metric("Reported consumption",f"{con['Actual Consumption (kg)'].sum():,.1f} kg","All report rows")
        with c[1]: metric("Average per report",f"{con['Actual Consumption (kg)'].mean():,.1f} kg","Daily / shift rows")
        with c[2]: metric("Average per vehicle",f"{con['Consumption / Vehicle (kg)'].mean():.3f} kg","Across report rows")
        fig=px.line(con.sort_values("Production Date"),x="Production Date",y="Actual Consumption (kg)",color="Shift",markers=True,title="Consumption trend"); fig.update_layout(height=330,paper_bgcolor="white",plot_bgcolor="white"); st.plotly_chart(fig,use_container_width=True)
        st.dataframe(con.sort_values("Production Date",ascending=False),use_container_width=True,hide_index=True); st.download_button("⬇ Download consumption CSV",con.to_csv(index=False).encode("utf-8"),"sealer_consumption_report.csv","text/csv")

elif page=="Storage Area View":
    st.markdown('<div class="section-title">Digital sealer storage area</div>',unsafe_allow_html=True)
    st.caption("Illustrative rack layout. Replace locations with your plant's actual rack/bin map.")
    d=inventory()
    if not d.empty:
        c=st.columns(3); types=c[0].multiselect("Sealer type",sorted(d["Sealer Type"].unique()),default=sorted(d["Sealer Type"].unique())); locs=c[1].multiselect("Location",sorted(d["Location"].unique()),default=sorted(d["Location"].unique())); statuses=c[2].multiselect("Status",["Full","In Use","Low Level","Empty"],default=["Full","In Use","Low Level","Empty"])
        filtered=d[d["Sealer Type"].isin(types)&d["Location"].isin(locs)&d["Status"].isin(statuses)]; cols=st.columns(3)
        for i,(_,r) in enumerate(filtered.iterrows()):
            cls="normal" if r["Status"] in ["Full","In Use"] else "low" if r["Status"]=="Low Level" else "empty"
            with cols[i%3]:
                st.markdown(f'''<div class="metric-card"><div style="display:flex;justify-content:space-between;align-items:center"><b style="font-size:17px;color:#142b40">{r['Drum ID']}</b><span class="status {cls}">{r['Status'].upper()}</span></div><div style="color:#718096;font-size:12px;margin-top:6px">{r['Sealer Name']} · {r['Sealer Type']}</div><div style="font-family:'Space Grotesk';font-size:25px;font-weight:700;color:#142b40;margin-top:12px">{r['Net (kg)']:.1f} <span style="font-size:13px;color:#718096">kg</span></div><div style="background:#e9eff5;border-radius:10px;height:8px;margin:8px 0"><div style="width:{r['Remaining (%)']}%;background:{'#15966b' if r['Remaining (%)']>50 else '#e7a126' if r['Remaining (%)']>0 else '#9aa6b2'};height:8px;border-radius:10px"></div></div><div style="display:flex;justify-content:space-between;color:#718096;font-size:12px"><span>{r['Remaining (%)']:.1f}% remaining</span><span>{r['Location']}</span></div></div>''',unsafe_allow_html=True)
                if st.button(f"View {r['Drum ID']} details",key=f"view_{r['Drum ID']}",use_container_width=True): st.session_state.view_drum_id=r["Drum ID"]
        selected=st.session_state.get("view_drum_id")
        if selected in d["Drum ID"].values:
            r=d[d["Drum ID"]==selected].iloc[0]; st.markdown(f"#### Drum details · {selected}")
            st.json({"Drum ID":selected,"Sealer name":r["Sealer Name"],"Type":r["Sealer Type"],"SAP code":r["SAP Code"],"Lot / batch":r["Lot/Batch"],"Capacity (kg)":float(r["Capacity (kg)"]),"Tare (kg)":float(r["Tare (kg)"]),"Simulated gross weight (kg)":float(r["Gross Weight (kg)"],),"Remaining quantity (kg)":float(r["Net (kg)"],),"Remaining (%)":float(r["Remaining (%)"],),"Status":r["Status"],"Location":r["Location"],"Date received":str(r["Date Received"]),"Expiry date":str(r["Expiry Date"])})
            st.markdown("**Transaction history**"); st.dataframe(st.session_state.transactions[st.session_state.transactions["Drum ID"]==selected],use_container_width=True,hide_index=True)
    else: st.info("No drums found. Add drums in Drum Inventory.")

elif page=="Reports & Export":
    st.markdown('<div class="section-title">Reports & data export</div>',unsafe_allow_html=True)
    d=inventory(); cols=["Drum ID","Sealer Name","Sealer Type","SAP Code","Lot/Batch","Capacity (kg)","Tare (kg)","Gross Weight (kg)","Net (kg)","Remaining (%)","Status","Location","Date Received","Expiry Date"]
    st.markdown("#### Current inventory report"); st.dataframe(d[cols],use_container_width=True,hide_index=True); st.download_button("⬇ Download current inventory CSV",d[cols].to_csv(index=False).encode("utf-8"),"current_sealer_inventory.csv","text/csv")
    st.markdown("#### Low-stock report"); low=d[d["Status"].isin(["Low Level","Empty"])]
    if low.empty: st.success("No drums currently classified as Low Level or Empty.")
    else: st.dataframe(low[cols],use_container_width=True,hide_index=True)
    st.download_button("⬇ Download low-stock CSV",low[cols].to_csv(index=False).encode("utf-8"),"low_stock_report.csv","text/csv")
    st.markdown("#### Receipt and issue history"); tx=st.session_state.transactions.copy(); st.dataframe(tx[tx["Type"].isin(["Material Received","Material Issued","Material Returned"])],use_container_width=True,hide_index=True); st.download_button("⬇ Download all transactions CSV",tx.to_csv(index=False).encode("utf-8"),"material_movement_history.csv","text/csv")
    st.markdown("#### Shift-wise consumption report"); con=st.session_state.consumption.copy(); st.dataframe(con,use_container_width=True,hide_index=True); st.download_button("⬇ Download shift consumption CSV",con.to_csv(index=False).encode("utf-8"),"shift_consumption_report.csv","text/csv")
    if st.button("Prepare Excel workbook",type="primary"):
        buffer=io.BytesIO()
        with pd.ExcelWriter(buffer,engine="openpyxl") as writer:
            d[cols].to_excel(writer,sheet_name="Inventory",index=False); st.session_state.transactions.to_excel(writer,sheet_name="Transactions",index=False); st.session_state.consumption.to_excel(writer,sheet_name="Consumption",index=False)
            pd.DataFrame([{"Physical Inventory (kg)":total,"SAP / Book Stock (kg)":st.session_state.book_stock,"Average Daily Consumption (kg)":avg,"Lead Time (days)":st.session_state.lead_time,"Safety Stock (kg)":st.session_state.safety_stock,"Reorder Point (kg)":reorder_point,"Estimated Days Remaining":days_left}]).to_excel(writer,sheet_name="Summary",index=False)
        st.download_button("⬇ Download Excel workbook",buffer.getvalue(),"digital_sealer_demo_report.xlsx","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

st.markdown("---")
st.markdown("<div style='text-align:center;color:#8190a2;font-size:11px;padding:4px'>DIGITAL SEALER INVENTORY MONITORING SYSTEM · DEMO BUILD · SIMULATED READINGS ONLY · NOT CONNECTED TO SAP OR PLANT HARDWARE</div>",unsafe_allow_html=True)
